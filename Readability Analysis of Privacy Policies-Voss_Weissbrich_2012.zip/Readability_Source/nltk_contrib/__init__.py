"""
UiA - (2007)

This is a project in the course IKT407-WebMining @ UiA
It is developed with intention to be a plugin to NLTK ( http://www.nltk.org )

Thomas Jakobsen - thomj05@student.uia.no
Thomas Skardal  - thomas04@student.uia.no
"""

